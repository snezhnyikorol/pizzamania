// ------------------------------------BASKET-----------------------------------

// let data = {
// 	count: 1,
// 	price: 300,
// 	0: {
// 		image: "./assets/img/pizza_img.png",
// 		name: "Пицца",
// 		size: "30см",
// 		price: "300",
// 		count: 3
// 	}
// };


let data =  cart.data;



// document.addEventListener('cartAvailable', function() {
// 	$('#basket').popover('dispose');

// 	updateBasket();


// 	$('#basket').popover({
// 		container: 'body',
// 		content: 'hellooooooooooooo',
// 		placement: 'bottom',
// 		title: 'hello',
// 		trigger: 'manual',
// 		template: basketTemplate,
// 		// boundary: document.getElementById('actions_slider').children[0]
// 	})

// })

// let basketSvg = `<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
// <path d="M14.75 6H5.25L5.90993 15.8047C5.97132 16.8184 6.50848 17.5 7.39863 17.5H12.6014C13.4915 17.5 14.0133 16.8184 14.0901 15.8047L14.75 6Z" fill="#373535"></path>
// <path d="M13.8498 3.00681L6.19643 3.00688C4.98382 2.88702 5.02127 4.36489 5 5L14.9917 4.99999C15.0165 4.38088 15.0624 3.12667 13.8498 3.00681Z" fill="#373535"></path>
// </svg>`;

let basketSvg = `<img src="./assets/img/icons/delete.svg">`

function increaseItem(id) {
	let count = cart.getItemById(id).count;
	count++;
	cart.updateItemCountById(id, count);
	$('[data-id='+id+']').filter('.basket_item').find('.basket_count').text(count);
	$('[data-id='+id+']').filter('.basket_item').find('.price_value').text((cart.getItemById(id).price * count).toString().replace('.', ','));
	$('#totalPrice').text(data.price.toString().replace('.', ','));
}

function decreaseItem(id) {
	let count = cart.getItemById(id).count;
	count--;
	if (count === 0) {
		deleteItem(id);
	} else {
		cart.updateItemCountById(id, count);
		$('[data-id='+id+']').filter('.basket_item').find('.basket_count').text(count);
		$('[data-id='+id+']').filter('.basket_item').find('.price_value').text((cart.getItemById(id).price * count).toString().replace('.', ','));
		$('#totalPrice').text(data.price.toString().replace('.', ','));
	}
}

function generateItem(item) {
	let subtitle = "";
	if (item.hasOwnProperty('components')) {
		for (const index in item.components) {
			if (item.components.hasOwnProperty(index)) {
				const component = item.components[index];
				subtitle = subtitle + `${component.name}<br>`;
			}
		}
		subtitle = subtitle.slice(0, subtitle.length - 4);
	} else {
		if (item.hasOwnProperty('size')) {
			subtitle = item.size;
		} else {
			subtitle = '';
		}

	}
	console.log(item)
	let template = $()
	return `<div class="basket_item" data-id=${item.id}>
  <div class="row">
  <div class="col-4 basket_img">
    <img src=${item.image} alt=${item.name}>
  </div>
  <div class="col-8 basket_content container">
    <div class="row">
      <div class="col-10">
        <h3 class="basket_title">${item.name}</h3>
        <h5 class="basket_subtitle">${subtitle}</h5>
      </div>
      <div class="col-2 px-0 d-flex justify-content-center align-items-start basket_delete" onclick="deleteItem('${item.id}')">
        ${basketSvg}
      </div>
    </div>
    <div class="row mt-2">
      <div class="col-12">
        <div class="row">
          <div class="col-6 amount_container d-flex justify-content-start align-items-center">
            <div class="amount_changer" onclick="decreaseItem('${item.id}')">
              <span>–</span>
            </div>
            <h6 class="mx-1"><span class="basket_count">${item.count}</span></h6>
            <div class="amount_changer" onclick="increaseItem('${item.id}')">
              <span>+</span>
            </div>
          </div>
          <div class="col-6">
            <p class="basket_popover-price text-right"><span class="price_value">${(Math.round(item.price*100) * item.count / 100).toString().replace('.', ',')}</span> руб</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
</div>`
}

let basketTemplate;

function generateBasket() {
	if (data.count == 0) {
		return `<div class="container popover basket_popover">
		<div class="arrow"></div>
		<div class="basket_body d-flex justify-content-center align-items-center">
		<h6>Корзина пуста</h6>
		</div>
		</div>
		</div>`
	} else {
		let temp = $(`<div><div class="container popover basket_popover">
		<div class="arrow"></div>
		<div class="basket_body">
		</div>
		<div class="basket_footer">
		<div class="row">
		<div class="col-6"><p>Сумма заказа</p></div>
		<div class="col-6 text-right"><p><span id="totalPrice">${data.price.toString().replace('.', ',')}</span> руб.</p></div>
		</div>
		</div>
		</div>
		</div>`);
		const items = data.items;
		for (const index in items) {
			if (items.hasOwnProperty(index)) {
				const item = items[index];
				// let busketItem = generateItem(item);
				$(temp).find('.basket_body').append(generateItem(item));
			}
		}
		return temp.html();
	}
}


function deleteItem(id) {
	let item = $('[data-id='+id+']').filter('.basket_item');
	cart.deleteItemById(id);
	$('#totalPrice').text(data.price.toString().replace('.', ','))
	$(item).remove();
	if (data.count == 0) {
		$('.basket_popover').html(`<div class="arrow"></div>
		<div class="basket_body d-flex justify-content-center align-items-center">
		<h6>Корзина пуста</h6>
		</div>
		</div>`);
	}
}



function updateBasket() {
	$('#basket').popover('dispose')
	basketTemplate = generateBasket();
	console.log(basketTemplate)
	$('#basket').popover({
		container: 'body',
		content: 'hellooooooooooooo',
		placement: 'bottom',
		title: 'hello',
		trigger: 'manual',
		template: basketTemplate,
		// boundary: document.getElementById('actions_slider').children[0]
	})
}


updateBasket();


$('#basket').popover({
	container: 'body',
	content: 'hellooooooooooooo',
	placement: 'bottom',
	title: 'hello',
	trigger: 'manual',
	template: basketTemplate,
	// boundary: document.getElementById('actions_slider').children[0]
})

$('#basket').mouseenter(
  function(){
		let isOver = false;
		$('#basket').popover('show');
    $('.basket_popover').mouseleave(
      function(){
        $('#basket').popover('hide')
      }
		);
		$('#basket').mouseleave(
      function(e){
				setTimeout(function () {
					if (!isOver) {
						$('#basket').popover('hide')
					}
				}, 300)
      }
		)
		$('.basket_popover').mouseenter(
			function(e){
				isOver = true;
				}
		)
  }
)

window.addEventListener('storage', function(e) {
	data = data = JSON.parse(localStorage.getItem('cart'));
	updateBasket();


$('#basket').popover({
	container: 'body',
	content: 'hellooooooooooooo',
	placement: 'bottom',
	title: 'hello',
	trigger: 'manual',
	template: basketTemplate,
	// boundary: document.getElementById('actions_slider').children[0]
})
});

// $('.basket_delete').on('click', function(e) {
// 	$(this).trigger('delete');
// })
// $('.basket_item').on('delete', function() {
// 	deleteItem(this);
// })

// -----------------BASKET END----------------------------

